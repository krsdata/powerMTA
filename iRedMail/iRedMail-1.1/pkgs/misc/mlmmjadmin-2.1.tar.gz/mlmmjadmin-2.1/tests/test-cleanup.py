from utils import remove_ml


def test_cleanup():
    remove_ml()
