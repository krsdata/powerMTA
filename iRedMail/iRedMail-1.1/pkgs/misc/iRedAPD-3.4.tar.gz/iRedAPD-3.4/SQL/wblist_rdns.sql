-- Blacklists
-- Chinese
INSERT INTO wblist_rdns (rdns, wb) VALUES ('.dynamic.163data.com.cn', 'B');

-- INSERT INTO wblist_rdns (rdns, wb) VALUES ('.hostinglotus.cloud', 'B');
INSERT INTO wblist_rdns (rdns, wb) VALUES ('.cable.dyn.cableonline.com.mx', 'B');
-- INSERT INTO wblist_rdns (rdns, wb) VALUES ('.bestel.com.mx', 'B');
INSERT INTO wblist_rdns (rdns, wb) VALUES ('.dyn.user.ono.com', 'B');
INSERT INTO wblist_rdns (rdns, wb) VALUES ('.static.skysever.com.br', 'B');
INSERT INTO wblist_rdns (rdns, wb) VALUES ('.castelecom.com.br', 'B');
INSERT INTO wblist_rdns (rdns, wb) VALUES ('.clients.your-server.de', 'B');
-- INSERT INTO wblist_rdns (rdns, wb) VALUES ('.hsd1.mi.comcast.net', 'B');

-- INSERT INTO wblist_rdns (rdns, wb) VALUES ('.fastwebnet.it', 'B');
