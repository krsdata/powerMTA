Upgrade/migration tutorials are available here:
http://www.iredmail.org/docs/iredapd.releases.html
